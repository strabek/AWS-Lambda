from __future__ import print_function

import boto3
import json
import requests
import logging
import os

# DynamoDB settings
dynamoDB_table = os.environ['DynamoDB_table']
dynamoDBClient = boto3.client('dynamodb')

logger = logging.getLogger()
logger.setLevel(logging.INFO) 

try:
    logger.info("Starting connection")
    conn = pymysql.connect(host, user=username, passwd=password, db=db_name, ssl={'ca':db_ssl_cert}, autocommit=True)
    logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
except pymysql.InternalError as error:
    code, message = error.args
    print(">>>>>>>>>>>>>", code, message)
    sys.exit()

def lambda_handler(event, context):
    try:
        # HN stories
        hnStories = requests.get('https://hacker-news.firebaseio.com/v0/newstories.json')
    except requests.exceptions.Timeout as e:
        # The request timed out.
        # Catching this error will catch both
        # :exc:`~requests.exceptions.ConnectTimeout` and
        # :exc:`~requests.exceptions.ReadTimeout` errors.

        logger.error("Error: {}".format(e))
        return
    except requests.exceptions.HTTPError as e:
        logger.error("Error: {}".format(e))
        return
    except requests.exceptions.RequestException as e:
        logger.error("Error: {}".format(e))
        return

    logger.info(json.loads(hnStories))
    return

    # Add each story to DynamoDB
    for story in stories:
        itemId = hashlib.sha1(str(time.time()).replace('.','').encode('utf-8')).hexdigest()
        response = dynamoDBClient.put_item(
            TableName=dynamoDB_table,
            Item={
                "id": { "S": itemId },
                "title": { "S": str(row[mapping["AlertId"]]) },
                "summary": { "S": str(row[mapping["TenantId"]]) },
                "url": { "S": str(row[mapping["UserId"]]) },
                "date": { "S": str(row[mapping["Name"]]) }
            }
        )

    return